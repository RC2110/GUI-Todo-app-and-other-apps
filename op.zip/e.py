# # # # # # option = "Enter your choice:"
# # # # # # vars = []
# # # # # #
# # # # # # while True:
# # # # # #     var = input(option)
# # # # # #     var = var.title()
# # # # # #     print(var)
# # # # # #     vars.append(var)
# # # # # #     if var == str(0):
# # # # # #         break
# # # # # #
# # # # # # print(vars)
# # # # #
# # # # # pass1 = "Enter your password:"
# # # # # out = input(pass1)
# # # # #
# # # # # while out != "pass123":
# # # # #     print("try again")
# # # # #     out = input(pass1)
# # # # #
# # # # # print("password is right")
# # # #
# # # # i=1
# # # # while i<=100:
# # # #     print(i)
# # # #     i=i+1
# # #
# # # # list=[]
# # # # while True:
# # # #     name = input("Enter your name:")
# # # #     formatname = name.title()
# # # #     print(formatname)
# # # #     list.append(formatname)
# # # #     if name == str(0):
# # # #      break
# # # #
# # # # print(list)
# # #
# # # # countries = []
# # # #
# # # # while True:
# # # #     country = input("Enter the country: ")
# # # #     countries.append(country.title())
# # # #     print(countries)
# # #
# # # # greeting = "hello"
# # # # print(greeting.upper())
# # #
# # # # while True:
# # # #     print("Hello")
# # # #
# # # #
# # # # a={'a':[1, 2, 3,"df", 5, 8], "b":{"i": 3, "t":"hhbn", "q": (1, 3, 4)}, "c":10e+01}
# # # # import pickle
# # # # fh = open("new.pickle", "wb")
# # # # pickle.dump(a, fh)
# # # # fh.close()
# # # # fh.close()
# # # # a={'a': [1, 2, 3, 'df', 5, 8], 'b': {'i': 3, 't': 'hhbn', 'q': (1, 3, 4)}, 'c': 100.0}
# # # # import pickle
# # # # fh = open("new.pickle", "wb")
# # # # pickle.dump(a, fh)
# # # # fh.close()
# # #
# # # import pickle
# # # fh = open("new.pickle", "rb")
# # # g = pickle.load(fh)
# # # print(g)
# # # fh.close()
# #
# #
# # import pickle
# # g=open('123.pkly', 'rb')
# # q=pickle.load(g)
# # print(q)
# # g.close()
# #
# # import pickle
# # file= open('new.pkl', 'rb')
# # dat = pickle.load(file)
# # print(dat.describe_furn())
#
# # class Data:
# #     def __index__(self):
# #         return 42
# # x = Data()
# # print(int(x))
#
# # content=["this is going to be the text in file 1",
# #           "text in the second file is this one",
# #           "guess who?, the text in the third file"]
# #
# # filenames=['reynolds.txt', 'cello.txt', 'montex.txt']
# #
# # for i, j in zip(content, filenames):
# #     file=open(f'../test/{j}','w')
# #     file.writelines(i)
#
# # file=open('bear.txt', 'r')
# # print(file.read())
#
# # with open(r'C:\Users\rajaa\Downloads\members.txt', 'r') as file:
# #     members=file.readlines()
# #     file.close()
# #
# # with open(r'C:\Users\rajaa\Downloads\members.txt', 'w') as file:
# #     new_member= input("Enter a new member:") + '\n'
# #     members.append(new_member)
# #     file.writelines(members)
# #     file.close()
#
# # filenames = ['doc.txt', 'report.txt', 'presentation.txt']
# #
# # for i in filenames:
# #    with open(f'{i}', 'w') as file:
# #      file.write('Hello')
# #      file.close()
#
# # with open(r"C:\Users\rajaa\Downloads\a.txt", 'r') as file:
# #     print(file.read())
# #     file.close()
# # with open(r"C:\Users\rajaa\Downloads\b.txt", 'r') as file:
# #         print(file.read())
# #         file.close()
# # with open(r"C:\Users\rajaa\Downloads\c.txt", 'r') as file:
# #             print(file.read())
# #             file.close()
#
# # j=["a.txt","b.txt","c.txt"]
# #
# # for i in j:
# #     with open(rf'C:\Users\rajaa\Downloads\{i}', 'r') as file:
# #         print(file.read())
# #         file.close()
#
# # file = open("data.txt", 'w')
# #
# # file.write("100.12\n")
# # file.write("111.23\n")
# #
# # file.close()
#
# # filenames=['1.Saraswathi', '2.Krishna', '3.Brahmaoutra', '4.Ganga']
# #
# # filenames = [filename.replace('.', '-')+ '.txt' for filename in filenames]
# #
# # print(filenames)
#
# # temperatures = [10, 12, 14]
# #
# # file = open('file.txt', 'w')
# #
# # file.writelines([f'{i}\n' for i in temperatures])
#
# # day = input("Enter today's date(DD-MM-YY):")
# # mood = input("How will you rate yourself today in a scale of 1 to 10?") + '\n'
# # insights = input("Let your thoughts flow:") + '\n'
# #
# # with open(f'../test/{day}.txt', 'w') as file:
# #     file.write(mood + 2*)
# #     file.write(insights)
#
#
# password = input("Enter your password:")
# n=len(password)
# list={}
# if n > 8:
#     list["length"]=True
# else:
#     list["length"]=False
#
# m = False
# for i in password:
#     if i.isdigit():
#         m=True
# list["number"]=m
#
# n=False
# for i in password:
#     if i.isupper():
#         n=True
# list["case"]=n
#
# print(list)
# print(list.values())
#
# if all(list.values()):
#     print("Strong Password")
# else:
#     print("Weak Password")
#

while True:
    try:
      width=float(input("Enter the width of the rectangle:"))
      height=float(input("Enter the height of the rectangle:"))

      if width == height:
          print("it's a square not a rectangle")
          continue
      area = width * height

      print(area)
      break
    except ValueError:
        print("Enter a number.")
        continue











