def convert(feet_local, inches_local):
    metres= feet_local* 0.3048 + inches_local * 0.0254
    print(f"{feet_local}feet and {inches_local}inches is {metres}metres")
    return metres