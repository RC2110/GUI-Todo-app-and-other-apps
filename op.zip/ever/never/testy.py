content=["return! this is going "
         "to be the text in file 1",
          "text in the second file is this one",
          "guess who?, the text in the third file"]

filenames=['reynolds.txt', 'cello.txt', 'montex.txt']

for i, j in zip(content, filenames):
    file=open(f'..../test/{j}','w')
    file.writelines(i)