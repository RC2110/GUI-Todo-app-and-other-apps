def parse(feet_inches):
    ls=feet_inches.split(" ")
    feet_local = float(ls[0])
    inches_local = float(ls[1])
    return {"feet":feet_local, "inches":inches_local}

# def water_state(temp):
#     if temp<=0:
#         return "Solid"
#     elif temp>0 and temp<100:
#         return "Liquid"
#     elif temp>=100:
#         return "Gas"

def water_state(temperature):
        FREEZING_POINT = int(0)
        BOILING_POINT = int(100)
        if temperature <= FREEZING_POINT:
            return "Solid"
        elif FREEZING_POINT < temperature < BOILING_POINT:
            return "Liquid"
        else:
            return "Gas"

if __name__ == "__main__":
    print(water_state(103))
    print(__name__)

fnme="gffyu"



